"""Measure the reader's default text; this is not a visual quality grader.

Python standard library only. Closed details text is excluded; summary remains.
Visible referenced SVG text is included. Bitmap text needs separate visual review.
"""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit, unquote
import argparse
import json
import re
import xml.etree.ElementTree as ET
from collections import Counter

compact = lambda value: re.sub(r"\s+", "", value)
VOID = {"img", "br", "hr", "meta", "link", "input", "source", "area", "base", "wbr", "embed", "param", "track", "col"}

class Reader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.text = []
        self.paragraphs = []
        self.all_paragraphs = []
        self.svg_refs = []
        self.images = []

    def visible(self):
        if any(x["skip"] for x in self.stack):
            return False
        closed = [i for i, x in enumerate(self.stack) if x["tag"] == "details" and not x["open"]]
        return not closed or all(any(x["tag"] == "summary" for x in self.stack[i+1:]) for i in closed)

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        entry = {"tag": tag, "skip": tag in {"head", "script", "style", "textarea", "template", "title", "desc"} or "hidden" in a or "sr-only" in a.get("class", "").split(), "open": "open" in a, "parts": [], "all_parts": []}
        self.stack.append(entry)
        if tag == "img" and self.visible():
            ref = a.get("src", "")
            self.images.append(ref)
            if urlsplit(ref).path.lower().endswith(".svg"):
                self.svg_refs.append(ref)
        if tag in VOID:
            self.stack.pop()

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        matches = [i for i, x in enumerate(self.stack) if x["tag"] == tag]
        if not matches:
            return
        i = matches[-1]
        for item in self.stack[i:]:
            if item["tag"] == "p":
                value = "".join(item["parts"])
                if compact(value):
                    self.paragraphs.append(value)
                all_value = "".join(item["all_parts"])
                if compact(all_value):
                    self.all_paragraphs.append(all_value)
        del self.stack[i:]

    def handle_data(self, data):
        if not any(x["skip"] for x in self.stack):
            for item in self.stack:
                if item["tag"] == "p":
                    item["all_parts"].append(data)
        if not self.visible():
            return
        self.text.append(data)
        for item in self.stack:
            if item["tag"] == "p":
                item["parts"].append(data)

def audit(path, budget=1100, paragraph_limit=90):
    path = Path(path).resolve()
    reader = Reader()
    reader.feed(path.read_text(encoding="utf-8-sig"))
    svg = []
    for ref in reader.svg_refs:
        parsed = urlsplit(ref)
        if parsed.scheme or parsed.netloc:
            svg.append({"ref": ref, "unmeasured_remote": True})
            continue
        target = path.parent / unquote(parsed.path)
        try:
            root = ET.parse(target).getroot()
            value = "".join("".join(node.itertext()) for node in root.iter() if node.tag.split("}")[-1] == "text")
            svg.append({"ref": ref, "characters": len(compact(value))})
        except (OSError, ET.ParseError) as error:
            svg.append({"ref": ref, "error": str(error)})
    html_chars = len(compact("".join(reader.text)))
    total = html_chars + sum(x.get("characters", 0) for x in svg)
    long_paragraphs = [{"characters": len(compact(p)), "text": p.strip()} for p in reader.paragraphs if len(compact(p)) > paragraph_limit]
    repeated = Counter(compact(p) for p in reader.all_paragraphs if len(compact(p)) >= 40)
    duplicates = [{"characters": len(p), "count": n, "text": p} for p, n in repeated.items() if n > 1]
    return {"default_html_characters": html_chars, "visible_external_svg_characters": total-html_chars, "combined_characters": total, "budget": budget, "within_budget": total <= budget, "paragraph_limit": paragraph_limit, "long_paragraphs": long_paragraphs, "duplicate_paragraphs_including_details": duplicates, "svg_measurements": svg, "default_images": reader.images, "bitmap_text_unmeasured": True, "visual_review_required": True}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("html")
    parser.add_argument("--budget", type=int, default=1100)
    parser.add_argument("--paragraph-limit", type=int, default=90)
    parser.add_argument("--output")
    args = parser.parse_args()
    result = audit(args.html, args.budget, args.paragraph_limit)
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    print(rendered)
    raise SystemExit(0 if result["within_budget"] and not result["duplicate_paragraphs_including_details"] else 1)
